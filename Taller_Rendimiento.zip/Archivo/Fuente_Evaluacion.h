/**************************************************************
		Pontificia Universidad Javeriana
	Autor: Santiago Lemus, Lucas Rivera, Paula Malagón
	Fecha: Mayo 2024
	Materia: Sistemas Operativos
	Tema: Taller de Evaluación de Rendimiento
	Fichero: fuente de multiplicación de matrices NxN por hilos.
	Objetivo: Evaluar el tiempo de ejecución del 
					algoritmo clásico de multiplicación de matrices.
				Se implementa con la Biblioteca POSIX Pthreads
****************************************************************/
#ifndef FUENTE_EVALUACION_H
#define FUENTE_EVALUACION_H

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#define DATA_SIZE (1024*1024*64*3)


extern pthread_mutex_t MM_mutex; // Mutex para control de acceso a recursos compartidos
static double MEM_CHUNK[DATA_SIZE]; // Bloque de memoria para matrices
extern double *mA, *mB, *mC; // Punteros para matrices A, B y C

struct parametros{
		int nH; // Número total de hilos
		int idH; // Identificador de hilo
		int N; // Tamaño de la matriz
};

extern struct timeval start, stop; // Variables para medir el tiempo de ejecución

void llenar_matriz(int SZ); // Función para llenar la matriz con valores aleatorios
void print_matrix(int sz, double *matriz); // Función para imprimir una matriz
void inicial_tiempo(); // Funciones para medir el tiempo de ejecución
void final_tiempo();//Funcion para calcular el tiempo de ejecucion
void *mult_thread(void *variables); // Función ejecutada por cada hilo para multiplicar las matrices

#endif /* FUENTE_EVALUACION_H */
