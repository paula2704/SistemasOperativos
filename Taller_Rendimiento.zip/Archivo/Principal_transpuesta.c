/**************************************************************
    Pontificia Universidad Javeriana
  Autor: Santiago Lemus, Lucas Rivera, Paula Malagón
  Fecha: Mayo 2024
  Materia: Sistemas Operativos
  Tema: Taller de Evaluación de Rendimiento
  Fichero: fuente de multiplicación de matrices NxN por hilos.
  Objetivo: Evaluar el tiempo de ejecución del 
          algoritmo clásico de multiplicación de matrices.
        Se implementa con la Biblioteca POSIX Pthreads
****************************************************************/
#include "mm_transpuesta.h"

int main(int argc, char *argv[]){
  if (argc < 3){ // Verifica si se proporcionan los argumentos necesarios
    printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
    return -1;	
  }
    int SZ = atoi(argv[1]); // Tamaño de la matriz (convertido de string a entero)
    int n_threads = atoi(argv[2]); // Número de hilos (convertido de string a entero)

    pthread_t p[n_threads]; // Arreglo de identificadores de hilo
    pthread_attr_t atrMM; // Atributos de los hilos

  mA = MEM_CHUNK; // Puntero al inicio del bloque de memoria
  mB = mA + SZ*SZ; // Puntero a la matriz B (desplazamiento)
  mC = mB + SZ*SZ; // Puntero a la matriz C (desplazamiento)

  llenar_matriz(SZ); // Llena las matrices con valores
  print_matrix(SZ, mA); // Imprime la matriz A
  print_matrix(SZ, mB); // Imprime la matriz B

  inicial_tiempo(); // Inicia la medición del tiempo
  pthread_mutex_init(&MM_mutex, NULL); // Inicializa el mutex
  pthread_attr_init(&atrMM); // Inicializa los atributos de los hilos
  pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE); // Configura los hilos como joinable

    for (int j=0; j<n_threads; j++){ // Bucle para crear los hilos
    struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros)); // Reserva memoria para los parámetros de cada hilo
    datos->idH = j; // Asigna el identificador de hilo
    datos->nH  = n_threads; // Asigna el número total de hilos
    datos->N   = SZ; // Asigna el tamaño de la matriz
        pthread_create(&p[j],&atrMM,mult_thread,(void *)datos); // Crea el hilo con los parámetros correspondientes
  }

    for (int j=0; j<n_threads; j++) // Bucle para esperar a que los hilos terminen
        pthread_join(p[j],NULL); // Espera a que el hilo termine su ejecución
  final_tiempo(); // Finaliza la medición del tiempo

  print_matrix(SZ, mC); // Imprime la matriz resultante

  pthread_attr_destroy(&atrMM); // Destruye los atributos de los hilos
  pthread_mutex_destroy(&MM_mutex); // Destruye el mutex
  pthread_exit (NULL); // Termina el programa
}